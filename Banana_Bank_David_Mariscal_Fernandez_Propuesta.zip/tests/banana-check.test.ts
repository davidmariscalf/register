import test from 'node:test';
import assert from 'node:assert/strict';
import { evaluateTransfer } from '../src/banking/review';
import type { Account, TransferInput } from '../src/types';

const transfer: TransferInput = {
  fromAccountId: 'acc-lucia',
  toAccountId: 'acc-bruno',
  amountCents: 2000,
  concept: 'Checks',
};
const source: Account = {
  id: 'acc-lucia', userId: 'lucia', label: 'Aurora', iban: 'TEST', balanceCents: 100000,
};
const recipient = { id: 'acc-bruno', label: 'Horizon', name: 'Bruno' };
const when = new Date('2026-09-24T12:00:00.000Z');

function evaluate(
  input = transfer,
  balance = source.balanceCents,
  movements: Array<{ accountId: string; amountCents: number; createdAt: string }> = [],
  completed: Array<{ payload: string; created_at: string }> = [],
) {
  return evaluateTransfer(input, { ...source, balanceCents: balance }, recipient, movements, completed, when);
}

test('Banana Check never authorizes spending beyond the current balance', () => {
  const result = evaluate({ ...transfer, amountCents: 100001 });
  assert.equal(result.canProceed, false);
  assert.equal(result.remainingCents, -1);
  assert.equal(result.signalLevel, 'high');
  assert.match(result.signals.join(' '), /Insufficient funds/);
});

test('An approved amount still receives transparent low-balance warnings', () => {
  const result = evaluate({ ...transfer, amountCents: 15000 }, 20000);
  assert.equal(result.canProceed, true);
  assert.equal(result.remainingCents, 5000);
  assert.equal(result.signalLevel, 'moderate');
  assert.match(result.signals.join(' '), /Less than €100/);
});

test('Only recent debits on the source account count as outgoing transfers', () => {
  const result = evaluate(transfer, 100000, [
    { accountId: 'acc-lucia', amountCents: -300, createdAt: '2026-09-23T09:00:00.000Z' },
    { accountId: 'acc-lucia', amountCents: -700, createdAt: '2026-08-01T09:00:00.000Z' },
    { accountId: 'acc-lucia', amountCents: 500, createdAt: '2026-09-23T10:00:00.000Z' },
    { accountId: 'acc-other', amountCents: -400, createdAt: '2026-09-23T10:00:00.000Z' },
  ]);
  assert.equal(result.outgoingLast30DaysCents, 300);
  assert.equal(result.outgoingSamples, 1);
});

test('Recent identical completed transfers are flagged but not silently blocked', () => {
  const result = evaluate(transfer, 100000, [], [
    { payload: JSON.stringify(transfer), created_at: '2026-09-24T08:00:00.000Z' },
  ]);
  assert.equal(result.signalLevel, 'high');
  assert.equal(result.canProceed, true);
  assert.match(result.signals.join(' '), /already recorded/);
});

test('Outdated and future records do not count as duplicate transfers', () => {
  const result = evaluate(transfer, 100000, [], [
    { payload: JSON.stringify(transfer), created_at: '2026-09-22T08:00:00.000Z' },
    { payload: JSON.stringify(transfer), created_at: '2026-10-01T08:00:00.000Z' },
  ]);
  assert.doesNotMatch(result.signals.join(' '), /already recorded/);
});

test('Malformed local history cannot crash the read-only review', () => {
  const result = evaluate(transfer, 100000, [], [
    { payload: '{invalid', created_at: '2026-09-24T10:00:00.000Z' },
  ]);
  assert.equal(result.canProceed, true);
  assert.match(result.note, /Nothing moves until you explicitly confirm/);
});
