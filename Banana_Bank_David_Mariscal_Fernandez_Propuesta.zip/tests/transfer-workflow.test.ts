/** Real signed HTTP API against the unmodified simulator, no model key required. */
import test, { after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn, type ChildProcess } from 'node:child_process';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import net from 'node:net';
const base = fs.mkdtempSync(path.join(os.tmpdir(), 'banana-integration-'));
process.env.DATA_DIR = path.join(base, 'app');
process.env.BANK_DATA_DIR = path.join(base, 'bank');
const server = net.createServer();
await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
const port = (server.address() as net.AddressInfo).port;
await new Promise<void>((resolve) => server.close(() => resolve()));
process.env.BANK_PORT = String(port);
process.env.BANK_URL = `http://127.0.0.1:${port}`;
const { seedApp } = await import('../src/seed');
const { closeAppDb, appDb } = await import('../src/db');
const { bankRequest } = await import('../src/banking/client');
const { transferMoney, transferStatus } = await import('../src/banking/actions');
const { caseDetail } = await import('../src/operator/view');
const { evaluateTransfer } = await import('../src/banking/review');
const { sessionToken } = await import('../src/auth');
const { POST, GET } = await import('../app/api/[...path]/route');
let child: ChildProcess | undefined;
let stderr = '';
async function startBank() {
  child = spawn(process.execPath, ['--import', 'tsx', 'simulator/server.ts'], {
    cwd: process.cwd(),
    env: { ...process.env, BANK_PORT: String(port), BANK_URL: process.env.BANK_URL },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  child.stderr?.on('data', (c) => { stderr += c.toString(); });
  for (let attempt = 0; attempt < 75; attempt++) {
    if (child.exitCode !== null) throw new Error(`Bank stopped: ${stderr}`);
    try {
      const response = await fetch(`${process.env.BANK_URL}/health`);
      if (response.ok) return;
    } catch {}
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`Bank did not start: ${stderr}`);
}
async function scenario(profile: string) {
  const response = await fetch(`${process.env.BANK_URL}/admin/scenario`, {
    method: 'POST',
    headers: { authorization: `Bearer ${process.env.BANK_ADMIN_SECRET || 'banana-local-admin'}`, 'content-type': 'application/json' },
    body: JSON.stringify({ profile }),
  });
  assert.equal(response.status, 200, await response.text());
}
const input = { fromAccountId: 'acc-lucia', toAccountId: 'acc-bruno', amountCents: 1200, concept: 'Safety trial' };
function ctx(intentId: string, approvalId?: string) {
  return { userId: 'lucia', conversationId: null, runId: randomUUID(), intentId, approvalId };
}
async function balance() {
  const accounts = await bankRequest<{ id: string; balanceCents: number }[]>('lucia', '/v1/accounts');
  return accounts.find((a) => a.id === input.fromAccountId)!.balanceCents;
}
async function propose(intentId: string, payload = input) {
  const before = await balance();
  const proposal = await transferMoney(ctx(intentId), payload);
  assert.equal(proposal.status, 'requires_confirmation');
  assert.equal(await balance(), before, 'proposing cannot debit');
  assert.ok(proposal.review, 'explainable review attached');
  return { before, proposal };
}
async function confirm(intentId: string, approvalId: string, payload = input) {
  return transferMoney(ctx(intentId, approvalId), payload);
}
test('full transfer workflow over signed bank boundary', async () => {
  seedApp();
  await startBank();
  await scenario('normal');
  let id = randomUUID();
  let { before, proposal } = await propose(id);
  assert.equal((await transferMoney(ctx(id), input)).approvalId, proposal.approvalId);
  await assert.rejects(() => transferMoney(ctx(id), { ...input, amountCents: 1201 }), /another request/);
  let answer = await confirm(id, String(proposal.approvalId));
  assert.equal(answer.status, 'completed');
  assert.equal(await balance(), before - input.amountCents);
  answer = await confirm(id, String(proposal.approvalId));
  assert.equal(answer.status, 'completed');
  assert.equal(await balance(), before - input.amountCents, 'double confirmation cannot duplicate');

  // Exercise public web endpoints too: tools only PROPOSE; only the confirmation route may write.
  const cookie = `banana_actor=${sessionToken('lucia')}`;
  const apiAction = await POST(new Request('http://localhost/api/actions', {
    method: 'POST', headers: { cookie, 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'transfer_money', arguments: input, intentId: randomUUID() }),
  }), { params: Promise.resolve({ path: ['actions'] }) });
  assert.equal(apiAction.status, 200);
  const apiProposal = await apiAction.json();
  assert.equal(apiProposal.status, 'requires_confirmation');
  assert.equal(await balance(), before - input.amountCents);
  const reviewReply = await POST(new Request('http://localhost/api/transfer-review', {
    method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: JSON.stringify(input),
  }), { params: Promise.resolve({ path: ['transfer-review'] }) });
  assert.equal(reviewReply.status, 200);
  assert.ok((await reviewReply.json()).note);
  const forbidOperator = await POST(new Request('http://localhost/api/actions', {
    method: 'POST', headers: { cookie: `banana_actor=${sessionToken('marta')}`, 'content-type': 'application/json' },
    body: JSON.stringify({ name: 'transfer_money', arguments: input }),
  }), { params: Promise.resolve({ path: ['actions'] }) });
  assert.equal(forbidOperator.status, 403);
  const confirmedViaApi = await POST(new Request(`http://localhost/api/approvals/${apiProposal.approvalId}/confirm`, {
    method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: '{}',
  }), { params: Promise.resolve({ path: ['approvals', apiProposal.approvalId, 'confirm'] }) });
  assert.equal(confirmedViaApi.status, 200);
  assert.equal((await confirmedViaApi.json()).status, 'completed');
  assert.equal((await GET(new Request(`http://localhost/api/transfers/${apiProposal.intentId}`, { headers: { cookie } }), {
    params: Promise.resolve({ path: ['transfers', apiProposal.intentId] }),
  })).status, 200);

  await scenario('lost-response');
  id = randomUUID(); ({ before, proposal } = await propose(id));
  answer = await confirm(id, String(proposal.approvalId));
  assert.equal(answer.status, 'completed', 'lost response reconciles against bank');
  assert.equal(await balance(), before - input.amountCents);
  assert.equal((await transferStatus(ctx(id))).status, 'completed');

  await scenario('read-unavailable');
  id = randomUUID(); ({ before, proposal } = await propose(id));
  answer = await confirm(id, String(proposal.approvalId));
  assert.equal(answer.status, 'pending_verification', 'unavailable lookup must not claim failure');
  assert.equal(await balance(), before - input.amountCents, 'bank may have committed');
  assert.equal((await transferStatus(ctx(id))).status, 'completed');
  assert.equal(await balance(), before - input.amountCents, 'recovery is read-only');

  await scenario('reject-before');
  id = randomUUID(); ({ before, proposal } = await propose(id));
  answer = await confirm(id, String(proposal.approvalId));
  assert.equal(answer.status, 'completed', 'retry uses exact same reference');
  assert.equal(await balance(), before - input.amountCents);

  await scenario('normal');
  // The seeded historical local 'failed' intent is in fact completed in the bank.
  const legacy = await transferStatus(ctx('intent-historic-lucia'));
  assert.equal(legacy.status, 'completed', 'historical ambiguous status must reconcile against bank');

  const id2 = randomUUID();
  ({ before, proposal } = await propose(id2));
  answer = await confirm(id2, String(proposal.approvalId));
  assert.equal(answer.status, 'completed', 'distinct intent permits a distinct legitimate transfer');
  assert.equal(await balance(), before - input.amountCents);

  // Hardening: an approval token must match the exact customer, payload and intent.
  await scenario('normal');
  const guardId = randomUUID();
  const guard = await propose(guardId);
  const guardBalance = await balance();
  await assert.rejects(() => confirm(guardId, randomUUID()), /not authorized/);
  assert.equal(await balance(), guardBalance, 'wrong approval token cannot move money');
  const foreignConfirm = await POST(new Request(`http://localhost/api/approvals/${guard.proposal.approvalId}/confirm`, {
    method: 'POST',
    headers: { cookie: `banana_actor=${sessionToken('bruno')}`, 'content-type': 'application/json' },
    body: '{}',
  }), { params: Promise.resolve({ path: ['approvals', String(guard.proposal.approvalId), 'confirm'] }) });
  assert.equal(foreignConfirm.status, 404, 'a different customer cannot approve a transfer');
  assert.equal(await balance(), guardBalance, 'foreign confirmation cannot move money');
  await assert.rejects(() => confirm(guardId, String(guard.proposal.approvalId), {
    ...input, amountCents: input.amountCents + 1,
  }), /another request/, 'confirmation cannot alter the amount');
  appDb().prepare('UPDATE approvals SET expires_at=? WHERE id=?')
    .run('2000-01-01T00:00:00.000Z', guard.proposal.approvalId);
  await assert.rejects(() => confirm(guardId, String(guard.proposal.approvalId)), /expired/);
  assert.equal(await balance(), guardBalance, 'expired approval cannot move money');
  const forgedOrigin = await POST(new Request('http://localhost/api/transfer-review', {
    method: 'POST',
    headers: { cookie, origin: 'https://evil.example', host: 'localhost', 'content-type': 'application/json' },
    body: JSON.stringify(input),
  }), { params: Promise.resolve({ path: ['transfer-review'] }) });
  assert.equal(forgedOrigin.status, 403, 'cross-site request must be rejected');
  assert.equal(await balance(), guardBalance, 'CSRF attempt cannot move money');

  // Competing requests must not produce two debits for the same intent.
  const racedId = randomUUID();
  const raced = await propose(racedId);
  const racedBefore = await balance();
  const confirmations = await Promise.all([
    confirm(racedId, String(raced.proposal.approvalId)),
    confirm(racedId, String(raced.proposal.approvalId)),
  ]);
  assert.ok(confirmations.every((x) => ['completed', 'pending_verification'].includes(x.status)));
  assert.equal((await transferStatus(ctx(racedId))).status, 'completed');
  assert.equal(await balance(), racedBefore - input.amountCents,
    'concurrent confirmations must result in exactly one debit');

  await assert.rejects(() => transferStatus({ ...ctx(randomUUID()), userId: 'bruno' }), /not found/);
  const open = appDb().prepare('SELECT id FROM incidents LIMIT 1').get() as { id: string };
  const operator = await caseDetail('marta', open.id);
  assert.ok(operator.history.length > 0);
  assert.ok(Array.isArray(operator.events));
  assert.equal((appDb().prepare("SELECT COUNT(*) AS n FROM intents WHERE status='pending_verification'").get() as { n: number }).n, 0);
});
test('Banana Check signals are deterministic, non-executing heuristics', () => {
  const row = evaluateTransfer(input,
    { id: 'acc-lucia', userId: 'lucia', label: 'Aurora', iban: '', balanceCents: 1600 },
    { id: 'acc-bruno', label: 'Horizon', name: 'Bruno' },
    [], [{ payload: JSON.stringify(input), created_at: new Date().toISOString() }]);
  assert.equal(row.remainingCents, 400);
  assert.equal(row.signalLevel, 'high');
  assert.ok(row.signals.some((warning) => /already recorded/.test(warning)));
  assert.equal(row.canProceed, true);
});
after(() => {
  child?.kill('SIGTERM');
  closeAppDb();
  fs.rmSync(base, { recursive: true, force: true });
});
