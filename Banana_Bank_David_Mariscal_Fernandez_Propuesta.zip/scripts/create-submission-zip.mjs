/**
 * Standard-library-only, reproducible single ZIP packager for the t·Dots challenge.
 * Excludes secrets, Node dependencies, build outputs and Git internals.
 * Requires the full Node24 verification to have passed; does not fabricate results.
 * Can run on Windows, Linux or macOS without extra installation.
 */
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';

const root = path.resolve(import.meta.dirname, '..');
const reportPath = path.join(root, 'submission', 'node24-verification.json');
const outputName = 'Banana_Bank_David_Mariscal_Fernandez_ENTREGA_FINAL.zip';
const outputPath = path.join(root, outputName);

function fail(msg) { console.error(`ERROR: ${msg}`); process.exit(1); }
if (!fs.existsSync(reportPath)) fail('Falta submission/node24-verification.json. Ejecuta primero 01_VERIFICAR_NODE24.cmd.');
let report;
try { report = JSON.parse(fs.readFileSync(reportPath, 'utf8')); }
catch { fail('Informe Node24 ilegible. Vuelve a ejecutar la verificacion.'); }
const expectedChecks = ['npm ci', 'typecheck', 'test', 'production build'];
if (report.status !== 'passed' ||
    Number(String(report.node ?? '').match(/^v?(\d+)/)?.[1]) < 24 ||
    !expectedChecks.every(name => report.checks?.some(check => check.name === name && check.status === 'passed'))) {
  fail('La verificacion Node24 NO indica exito total. No generare un ZIP falsamente validado. Comparte el informe para corregir los errores.');
}

const roots = ['app', 'docs', 'fixtures', 'scripts', 'simulator', 'src', 'tests', 'submission', '.github'];
const rootFiles = ['.env.example', '.gitignore', '.nvmrc', '.prettierrc.json', 'AGENTS.md', 'CLAUDE.md',
  'README.md', 'next.config.ts', 'package-lock.json', 'package.json', 'tsconfig.json',
  '01_VERIFICAR_NODE24.cmd', '02_PROBAR_APLICACION.cmd', '04_CREAR_ZIP_FINAL.cmd', '03_EXTRAER_SESION_IA.cmd', 'INSTRUCCIONES_FINALES.txt'];
const excludedDirs = new Set(['.git', '.next', 'node_modules', '.data', 'coverage', 'test-results', '.cache', '.turbo', '.vercel']);
const excludedFiles = new Set(['.DS_Store', 'Thumbs.db', 'next-env.d.ts']);
const files = new Map();
function gather(p) {
  if (!fs.existsSync(p)) return;
  const stat = fs.statSync(p);
  if (stat.isDirectory()) {
    if (excludedDirs.has(path.basename(p))) return;
    for (const x of fs.readdirSync(p).sort()) gather(path.join(p, x));
    return;
  }
  if (!stat.isFile()) return;
  const name = path.basename(p);
  if (excludedFiles.has(name) || name.endsWith('.tsbuildinfo') || name.endsWith('.log') || name.endsWith('.zip')) return;
  if (name === '.env' || (name.startsWith('.env.') && name !== '.env.example')) return;
  files.set(path.relative(root, p).split(path.sep).join('/'), fs.readFileSync(p));
}
for (const item of [...roots, ...rootFiles]) gather(path.join(root, item));

const aiSessionFiles = [...files.keys()].filter(name =>
  name.startsWith('submission/ai-sessions/') &&
  /(?:sesion_original|exportacion_original|conversacion_completa|transcripcion_visible)/i.test(path.basename(name)) &&
  /\.(json|html|pdf|txt|md)$/i.test(name),
);
const nativeExportIncluded = aiSessionFiles.some(name => /\.(json|html)$/i.test(name) && !/transcripcion_visible/i.test(name));
const note = [
  '# Estado final verificable de Banana Bank',
  '',
  `- Informe Node.js: \`submission/node24-verification.json\`.`,
  `- Node usado: ${report.node}.`,
  `- Comprobaciones con resultado satisfactorio: ${expectedChecks.join(', ')}.`,
  `- Fecha de verificacion: ${report.endedAt ?? 'no proporcionada'}.`,
  `- Material adicional de IA declarado: ${aiSessionFiles.length ? aiSessionFiles.join(', ') : 'no adjuntado'}.`,
  `- Exportacion nativa completa de IA validada por el empaquetador: no (no se puede garantizar la integridad de una exportacion automatizadamente).`,
  '',
  'El registro reconstruido que ya existe en submission/ai-sessions/ no equivale a una exportacion original. Revisar los archivos originales personalmente antes de enviar.',
  '',
].join('\n');
files.set('submission/ESTADO_FINAL.md', Buffer.from(note, 'utf8'));

const crcTable = Array.from({ length: 256 }, (_, i) => {
  let c = i;
  for (let j = 0; j < 8; j++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
function crc32(bytes) {
  let c = 0xffffffff;
  for (const b of bytes) c = crcTable[(c ^ b) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function dosTime(date) {
  const year = Math.max(1980, Math.min(2107, date.getFullYear()));
  return {time: (date.getHours() << 11) | (date.getMinutes() << 5) | (Math.floor(date.getSeconds() / 2)),
    date: ((year - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate()};
}
const locals = [];
const centrals = [];
let offset = 0;
const timestamp = dosTime(new Date());
for (const [filename, data] of [...files.entries()].sort((a, b) => a[0].localeCompare(b[0]))) {
  const name = Buffer.from(filename, 'utf8');
  const compressed = zlib.deflateRawSync(data, { level: 9 });
  const crc = crc32(data);
  const header = Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50, 0);
  header.writeUInt16LE(20, 4);
  header.writeUInt16LE(0x800, 6); // UTF-8 file names
  header.writeUInt16LE(8, 8); // deflate
  header.writeUInt16LE(timestamp.time, 10);
  header.writeUInt16LE(timestamp.date, 12);
  header.writeUInt32LE(crc, 14);
  header.writeUInt32LE(compressed.length, 18);
  header.writeUInt32LE(data.length, 22);
  header.writeUInt16LE(name.length, 26);
  locals.push(header, name, compressed);

  const central = Buffer.alloc(46);
  central.writeUInt32LE(0x02014b50, 0);
  central.writeUInt16LE(20, 4);
  central.writeUInt16LE(20, 6);
  central.writeUInt16LE(0x800, 8);
  central.writeUInt16LE(8, 10);
  central.writeUInt16LE(timestamp.time, 12);
  central.writeUInt16LE(timestamp.date, 14);
  central.writeUInt32LE(crc, 16);
  central.writeUInt32LE(compressed.length, 20);
  central.writeUInt32LE(data.length, 24);
  central.writeUInt16LE(name.length, 28);
  central.writeUInt32LE(offset, 42);
  centrals.push(central, name);
  offset += header.length + name.length + compressed.length;
}
const centralData = Buffer.concat(centrals);
const end = Buffer.alloc(22);
end.writeUInt32LE(0x06054b50, 0);
end.writeUInt16LE(files.size, 8);
end.writeUInt16LE(files.size, 10);
end.writeUInt32LE(centralData.length, 12);
end.writeUInt32LE(offset, 16);
fs.writeFileSync(outputPath, Buffer.concat([...locals, centralData, end]));
console.log(`ZIP generado: ${outputPath}`);
console.log(`Archivos: ${files.size}; tamano: ${Math.round(fs.statSync(outputPath).size / 1024)} KiB`);
console.log('Node 24: todas las comprobaciones del verificador figuran como superadas.');
if (aiSessionFiles.length) {
  console.log(`Archivos adicionales de sesion incluidos: ${aiSessionFiles.join(', ')}`);
  if (!nativeExportIncluded) console.warn('AVISO: no se ha identificado una exportacion nativa en JSON/HTML; comprueba las condiciones.');
} else console.warn('AVISO IMPORTANTE: faltan las sesiones originales de IA; solo existe el registro reconstruido. Es un requisito independiente.');
console.log('Comprueba la ausencia de secretos y revisa el ZIP antes de enviar.');
