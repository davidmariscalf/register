/** Full reproducible Node 24 verification. No credentials or real bank accounts are needed.
 * Run from the project root: npm run verify:node24
 * Writes an honest result to submission/node24-verification.json.
 */
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const filename = path.join(root, 'submission', 'node24-verification.json');
const startedAt = new Date().toISOString();
const result = {
  startedAt, platform: `${process.platform}-${process.arch}`, node: process.version,
  npm: null, status: 'incomplete', checks: [],
};
function record() {
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  fs.writeFileSync(filename, JSON.stringify({ ...result, endedAt: new Date().toISOString() }, null, 2) + '\n');
}
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
function command(name, args) {
  console.log(`\n== ${name} ==`);
  const p = spawnSync(npm, args, { cwd: root, stdio: 'inherit', env: process.env, shell: process.platform === 'win32' });
  result.checks.push({ name, command: [npm, ...args].join(' '), status: p.status === 0 ? 'passed' : 'failed', exitCode: p.status, error: p.error?.message });
  record();
  if (p.status !== 0) process.exit(p.status || 1);
}
const major = Number(process.versions.node.split('.')[0]);
if (major < 24) {
  result.status = 'blocked';
  result.reason = `Node ${process.version} is installed; challenge requires Node >=24. Install Node 24 and run this script again.`;
  record();
  console.error(result.reason);
  process.exit(2);
}
result.npm = spawnSync(npm, ['--version'], { cwd: root, encoding: 'utf8', shell: process.platform === 'win32' }).stdout?.trim() || null;
record();
command('npm ci', ['ci', '--no-audit', '--no-fund']);
command('typecheck', ['run', 'typecheck']);
command('test', ['test']);
command('production build', ['run', 'build']);
result.status = 'passed';
record();
console.log('\nNode 24 verification PASSED. Report:', filename);
