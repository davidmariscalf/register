/** Extract only challenge-related native ChatGPT conversations, preserving originals.
 * Use a personal ChatGPT data export. No data leaves the computer.
 * Usage: node scripts/extract-chatgpt-session.mjs "C:\\path\\to\\conversations.json"
 */
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname, '..');
const supplied = process.argv[2];
if (!supplied) {
  console.error('Pasa la ruta de conversations.json de tu exportación nativa de ChatGPT.');
  process.exit(2);
}
let source = path.resolve(supplied);
if (fs.existsSync(source) && fs.statSync(source).isDirectory()) source = path.join(source, 'conversations.json');
if (!fs.existsSync(source)) { console.error(`Archivo no encontrado: ${source}`); process.exit(2); }
let exported;
try { exported = JSON.parse(fs.readFileSync(source, 'utf8')); }
catch (error) { console.error(`No se pudo leer el JSON: ${error.message}`); process.exit(1); }
const conversations = Array.isArray(exported) ? exported : exported?.conversations;
if (!Array.isArray(conversations)) { console.error('Formato ChatGPT desconocido: se esperaba un array de conversaciones.'); process.exit(1); }
const topic = /challenge[-\s]?banana[-\s]?candidate|banana[\s._-]*bank|t[·.\s-]?dots|hr@tdots\.es|hackathon\s+t[·.\s-]?dots/i;
function contentOf(c) {
  const messages = Object.values(c.mapping || {}).map(x => x?.message).filter(Boolean);
  if (Array.isArray(c.messages)) messages.push(...c.messages);
  return messages.map(m => {
    try { return JSON.stringify(m.content ?? m.text ?? ''); } catch { return ''; }
  }).join('\n');
}
const found = conversations.filter(c => topic.test(c.title || '') || topic.test(contentOf(c)));
if (!found.length) {
  console.error('Ninguna conversación menciona explícitamente Banana Bank/t·Dots. No se ha adivinado una sesión a partir de textos genéricos.');
  console.error('Revisa la exportación y contacta al asistente si el reto aparece con otro nombre.');
  process.exit(1);
}
if (found.length > 10) {
  console.error(`Se detectaron ${found.length} conversaciones posibles, demasiadas para exportarlas sin revisión.`);
  for (const c of found) console.error('Posible:', c.title || c.id || '(sin título)');
  process.exit(1);
}
const dir = path.join(root, 'submission', 'ai-sessions');
fs.mkdirSync(dir, { recursive: true });
// Remove only stale outputs created by this script. Never delete other session evidence.
for (const name of fs.readdirSync(dir)) {
  if (/^sesion_original_chatgpt_\d{2}\.json$/.test(name) || name === 'MANIFIESTO_EXPORTACION_CHATGPT.md')
    fs.rmSync(path.join(dir, name));
}
const lines = [
  '# Exportaciones originales de conversaciones del reto', '',
  'Procedencia: objetos de conversación recuperados de un fichero conversations.json de ChatGPT proporcionado por el candidato. Cada `conversation` se conserva sin recortar mensajes ni alterar `mapping`.',
  'Estas exportaciones no incluyen automáticamente adjuntos binarios externos: añadir por separado las imágenes, archivos o sesiones de otros proveedores IA utilizados.', '',
];
found.forEach((c, index) => {
  const file = `sesion_original_chatgpt_${String(index + 1).padStart(2, '0')}.json`;
  fs.writeFileSync(path.join(dir, file), JSON.stringify({ provenance: 'Extracted from native ChatGPT export; unmodified conversation follows.', conversation: c }, null, 2) + '\n', 'utf8');
  lines.push(`- \`${file}\`: ${String(c.title || '(sin título)').replace(/\s+/g, ' ').slice(0, 180)}`);
  console.log(`Extraída ${index + 1}/${found.length}: ${file} — ${c.title || '(sin título)'}`);
});
lines.push('', `Conversaciones candidatas extraídas: **${found.length}**.`, '',
  '**Revisión humana imprescindible:** comprobar que todos los archivos son realmente del reto, que no hay sesiones del reto omitidas y que no se incluyen datos privados de otros temas. Incorporar sesiones de otras herramientas IA manualmente si se usaron.', '',
  'No enviar el conversations.json global ni la exportación completa de ChatGPT al organizador.', '');
fs.writeFileSync(path.join(dir, 'MANIFIESTO_EXPORTACION_CHATGPT.md'), lines.join('\n'), 'utf8');
console.log('Completado. Revisa MANIFIESTO_EXPORTACION_CHATGPT.md antes de crear el ZIP final.');
