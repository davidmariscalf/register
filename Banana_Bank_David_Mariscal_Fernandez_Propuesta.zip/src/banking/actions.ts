/** Two-phase transfer state machine: propose -> explicit customer approval -> dispatch.
 * Machine/tool generated calls cannot provide the server-only approvalId.
 */
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { appDb } from '../db';
import { HttpError } from '../auth';
import { BankError } from './client';
import { person } from '../people';
import { dispatchTransfer, lookupTransfer } from './dispatch';
import { recordEvent } from '../telemetry';
import { reviewTransfer } from './review';
import type { ActionResult, ToolContext, TransferInput } from '../types';
export const transferSchema = z.object({
  fromAccountId: z.string().min(1),
  toAccountId: z.string().min(1),
  amountCents: z.number().int().positive().max(10000000),
  concept: z.string().max(200),
}).strict();

type IntentRow = {
  id: string; user_id: string; payload: string; status: string;
  bank_reference: string | null; operation_id: string | null; error: string | null;
};
type ApprovalRow = { id: string; user_id: string; intent_id: string; payload: string; expires_at: string; consumed_at: string | null };

function isUncertainLegacyFailure(intent: IntentRow): boolean {
  return intent.status === 'failed' && !!intent.bank_reference &&
    /no response|timed? ?out|timeout|unavailable|5\d\d/i.test(intent.error || '');
}

function readIntent(id: string): IntentRow | undefined {
  return appDb().prepare('SELECT * FROM intents WHERE id=?').get(id) as IntentRow | undefined;
}
async function resultOf(ctx: ToolContext, intent: IntentRow): Promise<ActionResult> {
  if (intent.status === 'completed')
    return { status: 'completed', intentId: ctx.intentId, reference: intent.bank_reference, operationId: intent.operation_id };
  if (intent.status === 'failed')
    return isUncertainLegacyFailure(intent)
      ? { status: 'pending_verification', intentId: ctx.intentId, reference: intent.bank_reference,
          message: 'Historical error did not prove rejection. Check the bank before trying again.' }
      : { status: 'failed', intentId: ctx.intentId, error: intent.error };
  if (intent.status === 'awaiting_confirmation') {
    const approval = appDb().prepare('SELECT * FROM approvals WHERE intent_id=? ORDER BY rowid DESC LIMIT 1')
      .get(ctx.intentId) as ApprovalRow | undefined;
    if (!approval || approval.consumed_at || approval.expires_at <= new Date().toISOString())
      return { status: 'expired', intentId: ctx.intentId, message: 'Start a new proposal to approve a transfer.' };
    return { status: 'requires_confirmation', intentId: ctx.intentId, approvalId: approval.id,
      expiresAt: approval.expires_at, preview: JSON.parse(intent.payload) };
  }
  return { status: 'pending_verification', intentId: ctx.intentId, reference: intent.bank_reference,
    message: 'The bank result is not verified. Use Check status before attempting another transfer.' };
}

/** Customer-safe read-only status recovery, never retries the write. */
export async function transferStatus(ctx: ToolContext): Promise<ActionResult> {
  const intent = readIntent(ctx.intentId);
  if (!intent || intent.user_id !== ctx.userId) throw new HttpError(404, 'Transfer intent not found.');
  if (intent.status !== 'pending_verification' && intent.status !== 'processing' && !isUncertainLegacyFailure(intent))
    return resultOf(ctx, intent);
  if (!intent.bank_reference) return resultOf(ctx, intent);
  try {
    const found = await lookupTransfer(ctx, intent.bank_reference);
    if (found) {
      appDb().prepare('UPDATE intents SET status=?,operation_id=?,error=NULL WHERE id=? AND user_id=?')
        .run('completed', found.id, ctx.intentId, ctx.userId);
      recordEvent(ctx, 'transfer.reconciled', { status: 'completed', reference: intent.bank_reference });
      return { status: 'completed', intentId: ctx.intentId, reference: intent.bank_reference, operation: found };
    }
    if (isUncertainLegacyFailure(intent))
      appDb().prepare("UPDATE intents SET status='pending_verification' WHERE id=? AND user_id=?")
        .run(ctx.intentId, ctx.userId);
    return { status: 'pending_verification', intentId: ctx.intentId, reference: intent.bank_reference,
      message: 'The bank has no recorded operation for this reference yet. No new transfer was issued. Contact support if this persists.' };
  } catch {
    return { status: 'pending_verification', intentId: ctx.intentId, reference: intent.bank_reference,
      message: 'Status lookup is currently unavailable. Do not attempt a new transfer.' };
  }
}

export async function transferMoney(ctx: ToolContext, args: unknown): Promise<ActionResult> {
  if (person(ctx.userId)?.role !== 'customer') throw new HttpError(403, 'A customer account is required.');
  const input: TransferInput = transferSchema.parse(args);
  const db = appDb();
  const raw = JSON.stringify(input);
  const existing = readIntent(ctx.intentId);
  if (existing && (existing.user_id !== ctx.userId || existing.payload !== raw))
    throw new HttpError(409, 'This intent already belongs to another request.');

  if (!ctx.approvalId) {
    if (existing) return resultOf(ctx, existing);
    // This is deliberately read-only; no agent call may cause a write to the ledger.
    const review = await reviewTransfer(ctx.userId, input);
    if (!review.canProceed) return { status: 'blocked', error: 'Insufficient funds for this proposal.', review };
    const now = new Date();
    const approvalId = randomUUID();
    const expires = new Date(now.getTime() + 30 * 60000).toISOString();
    db.transaction(() => {
      db.prepare('INSERT OR IGNORE INTO intents VALUES(?,?,?,?,?,?,?,?,?,?)').run(
        ctx.intentId, ctx.userId, ctx.conversationId, ctx.runId, raw,
        'awaiting_confirmation', null, null, null, now.toISOString(),
      );
      if (!db.prepare('SELECT 1 FROM approvals WHERE intent_id=?').get(ctx.intentId))
        db.prepare('INSERT INTO approvals VALUES(?,?,?,?,?,NULL)').run(approvalId, ctx.userId, ctx.intentId, raw, expires);
    })();
    const proposal = await resultOf(ctx, readIntent(ctx.intentId)!);
    recordEvent(ctx, 'transfer.proposed', { status: 'requires_confirmation', intentId: ctx.intentId, input, review });
    return { ...proposal, review };
  }

  const approval = db.prepare('SELECT * FROM approvals WHERE id=? AND intent_id=? AND user_id=?')
    .get(ctx.approvalId, ctx.intentId, ctx.userId) as ApprovalRow | undefined;
  if (!approval || approval.payload !== raw) throw new HttpError(403, 'This proposal is not authorized.');
  if (existing?.status === 'completed') return resultOf(ctx, existing);
  if (existing?.status === 'pending_verification' || existing?.status === 'processing')
    return transferStatus(ctx);
  if (existing?.status === 'failed') return isUncertainLegacyFailure(existing) ? transferStatus(ctx) : resultOf(ctx, existing);
  if (approval.expires_at <= new Date().toISOString()) throw new HttpError(410, 'Proposal expired. Create a new one.');
  if (approval.consumed_at) throw new HttpError(409, 'This approval has already been used.');
  // Claims the approval and its intent atomically. Concurrent requests cannot both dispatch.
  const claimed = db.transaction(() => {
    const updated = db.prepare("UPDATE intents SET status='processing' WHERE id=? AND user_id=? AND status='awaiting_confirmation'")
      .run(ctx.intentId, ctx.userId);
    if (updated.changes !== 1) return false;
    db.prepare('UPDATE approvals SET consumed_at=? WHERE id=? AND consumed_at IS NULL')
      .run(new Date().toISOString(), approval.id);
    return true;
  })();
  if (!claimed) return transferStatus(ctx);
  recordEvent(ctx, 'transfer.confirmed', { status: 'processing', intentId: ctx.intentId, input });
  try {
    const operation = await dispatchTransfer(ctx, input);
    db.prepare("UPDATE intents SET status='completed',operation_id=?,error=NULL WHERE id=? AND user_id=?")
      .run(operation.id, ctx.intentId, ctx.userId);
    recordEvent(ctx, 'transfer.completed', { status: 'completed', intentId: ctx.intentId, operation });
    return { status: 'completed', operation, intentId: ctx.intentId };
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown bank result.';
    const certain = error instanceof BankError && error.status >= 400 && error.status < 500;
    db.prepare('UPDATE intents SET status=?,error=? WHERE id=? AND user_id=?')
      .run(certain ? 'failed' : 'pending_verification', message, ctx.intentId, ctx.userId);
    recordEvent(ctx, 'transfer.dispatch_result', { status: certain ? 'failed' : 'pending_verification',
      intentId: ctx.intentId, error: message });
    return { status: certain ? 'failed' : 'pending_verification', error: message,
      intentId: ctx.intentId, reference: readIntent(ctx.intentId)?.bank_reference };
  }
}
