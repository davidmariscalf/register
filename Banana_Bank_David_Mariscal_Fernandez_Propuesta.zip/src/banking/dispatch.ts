/** All attempts for an intent use one persisted bank reference.
 * Reconciliation is always a signed GET via the public bank API.
 */
import { randomUUID } from 'node:crypto';
import { bankRequest, BankError } from './client';
import { appDb } from '../db';
import type { Operation, ToolContext, TransferInput } from '../types';

export async function lookupTransfer(ctx: ToolContext, reference: string): Promise<Operation | null> {
  try {
    return await bankRequest<Operation>(ctx.userId, `/v1/operations/${encodeURIComponent(reference)}`);
  } catch (error) {
    if (error instanceof BankError && error.status === 404) return null;
    throw error;
  }
}
export async function dispatchTransfer(ctx: ToolContext, input: TransferInput): Promise<Operation> {
  const db = appDb();
  // Persist *before* the first network call so timeouts never create a second key.
  const newReference = randomUUID();
  db.prepare('UPDATE intents SET bank_reference=COALESCE(bank_reference,?) WHERE id=? AND user_id=?')
    .run(newReference, ctx.intentId, ctx.userId);
  const saved = db.prepare('SELECT bank_reference FROM intents WHERE id=? AND user_id=?')
    .get(ctx.intentId, ctx.userId) as { bank_reference: string } | undefined;
  if (!saved?.bank_reference) throw new Error('Missing stored transfer intent.');
  const reference = saved.bank_reference;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await bankRequest<Operation>(ctx.userId, '/v1/transfers', 'POST', {
        ...input, reference,
      });
    } catch (error) {
      if (!(error instanceof BankError) || error.status < 500) throw error;
      // A 5xx or network timeout MAY occur after the transfer commits.
      // If verification is unavailable, return UNKNOWN; never claim failure.
      const found = await lookupTransfer(ctx, reference);
      if (found) return found;
      // The bank did not record the operation *at the time of the read*.
      // A replay with the same reference is safe under the bank's contract.
    }
  }
  const found = await lookupTransfer(ctx, reference);
  if (found) return found;
  throw new BankError(504, 'No completion could be verified. Do not create a new transfer to retry; check status or contact support.');
}
