/** Banana Check: deterministic, explainable context for an intended transfer.
 * Uses only the signed bank API for customer banking data; never changes money.
 * Warnings are heuristics, not fraud determinations or a guarantee of affordability.
 */
import { bankRequest } from './client';
import { appDb } from '../db';
import { HttpError } from '../auth';
import type { Account, TransferInput } from '../types';

type Contact = { id: string; name?: string; label: string };
type Movement = { accountId: string; amountCents: number; createdAt: string };
type PriorIntent = { payload: string; created_at: string };
export type TransferReview = {
  source: { id: string; label: string; balanceCents: number };
  recipient: { id: string; label: string; name: string };
  amountCents: number;
  concept: string;
  remainingCents: number;
  outgoingLast30DaysCents: number;
  outgoingSamples: number;
  signalLevel: 'low' | 'moderate' | 'high';
  signals: string[];
  canProceed: boolean;
  note: string;
};

export function evaluateTransfer(
  input: TransferInput,
  source: Account,
  recipient: Contact,
  movements: Movement[],
  completedIntents: PriorIntent[],
  now: Date = new Date(),
): TransferReview {
  const balance = source.balanceCents;
  const after = balance - input.amountCents;
  const signals: string[] = [];
  const thirtyDaysAgo = now.getTime() - 30 * 86400000;
  const recent = movements.filter((m) => m.accountId === source.id && m.amountCents < 0 &&
    Date.parse(m.createdAt) >= thirtyDaysAgo && Date.parse(m.createdAt) <= now.getTime());
  const outgoing = recent.reduce((sum, m) => sum - m.amountCents, 0);
  const previous = completedIntents.flatMap((entry) => {
    try {
      return [{ payload: JSON.parse(entry.payload) as TransferInput, when: Date.parse(entry.created_at) }];
    } catch { return []; }
  });
  const isRepeat = previous.some((p) => p.payload.toAccountId === input.toAccountId &&
    p.payload.amountCents === input.amountCents && p.when >= now.getTime() - 86400000 &&
    p.when <= now.getTime());
  const newRecipient = !previous.some((p) => p.payload.toAccountId === input.toAccountId);
  if (input.amountCents > balance) signals.push('Insufficient funds: the bank will reject this amount.');
  else if (after < 10000) signals.push('Less than €100 would remain in this account.');
  if (balance > 0 && input.amountCents * 2 >= balance)
    signals.push('This transfer uses at least half of the current account balance.');
  if (isRepeat) signals.push('A transfer of this amount to this recipient was already recorded in the last 24 hours. Check for duplicates.');
  if (newRecipient) signals.push('No previous completed transfer to this recipient is recorded in this app (not proof of a first-time payee).');
  const high = input.amountCents > balance || isRepeat;
  return {
    source: { id: source.id, label: source.label, balanceCents: balance },
    recipient: { id: recipient.id, label: recipient.label, name: recipient.name || 'Own account' },
    amountCents: input.amountCents,
    concept: input.concept,
    remainingCents: after,
    outgoingLast30DaysCents: outgoing,
    outgoingSamples: recent.length,
    signalLevel: high ? 'high' : signals.length ? 'moderate' : 'low',
    signals,
    canProceed: input.amountCents <= balance,
    note: 'Context only. Recent debits are not a forecast, and this check cannot detect all scams. Nothing moves until you explicitly confirm.',
  };
}
export async function reviewTransfer(userId: string, input: TransferInput): Promise<TransferReview> {
  const [accounts, contacts, movements] = await Promise.all([
    bankRequest<Account[]>(userId, '/v1/accounts'),
    bankRequest<Contact[]>(userId, '/v1/contacts'),
    bankRequest<Movement[]>(userId, '/v1/movements'),
  ]);
  const source = accounts.find((a) => a.id === input.fromAccountId);
  if (!source) throw new HttpError(403, 'This source account is not yours.');
  if (input.fromAccountId === input.toAccountId) throw new HttpError(400, 'Select a different destination.');
  const targetAccount = accounts.find((a) => a.id === input.toAccountId);
  const recipient = contacts.find((c) => c.id === input.toAccountId) ||
    (targetAccount ? { id: targetAccount.id, label: targetAccount.label, name: 'Own account' } : undefined);
  if (!recipient) throw new HttpError(400, 'Recipient account was not found.');
  const completed = appDb().prepare("SELECT payload,created_at FROM intents WHERE user_id=? AND status='completed'")
    .all(userId) as PriorIntent[];
  return evaluateTransfer(input, source, recipient, movements, completed);
}
