import { appDb } from '../db';
import { config } from '../config';
import { embedTexts } from './embeddings';
import { allChunks } from './store';
import { documents } from '../ingestion/pipeline';
import { referenceDate } from '../config';
import type { SearchResult } from '../types';
export async function searchDocuments(
  query: string,
  role = 'customer',
  limit = 5,
): Promise<SearchResult[]> {
  const meta = appDb().prepare('SELECT value FROM meta WHERE key=?').get('index-model') as
    { value: string } | undefined;
  if (!meta) throw new Error('No document index. Run npm run setup or npm run ingest.');
  if (meta.value !== config.embeddingModel)
    throw new Error('The model does not match the index. Re-ingest the documents.');
  const [queryVector] = await embedTexts([query]);
  const catalog = new Map(documents().map((d) => [d.id, d]));
  return allChunks()
    .filter((c) => {
      const doc = catalog.get(c.documentId);
      if (!doc) return false;
      if (role !== 'operator' && (doc.audience !== 'public' || doc.validFrom > referenceDate ||
        (doc.validTo !== null && doc.validTo < referenceDate))) return false;
      return true;
    })
    .map(({ vector, ...c }) => {
      const doc = catalog.get(c.documentId)!;
      if (vector!.length !== queryVector.length) throw new Error('Incompatible embedding dimensions.');
      const score = vector!.reduce((sum, v, i) => sum + v * queryVector[i], 0);
      return { ...c, title: doc.title, version: doc.version,
        validFrom: doc.validFrom, validTo: doc.validTo, audience: doc.audience, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}
