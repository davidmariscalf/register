import { appDb } from '../db';
import { person } from '../people';
import { HttpError } from '../auth';
import { bankRequest } from '../banking/client';
export async function caseDetail(operatorId: string, id: string) {
  if (person(operatorId)?.role !== 'operator') throw new HttpError(403, 'Operator role required.');
  const db = appDb();
  const incident = db.prepare('SELECT * FROM incidents WHERE id=?').get(id) as any;
  if (!incident) throw new HttpError(404, 'Case not found.');
  const history = db.prepare('SELECT * FROM messages WHERE conversation_id=? ORDER BY created_at,rowid')
    .all(incident.conversation_id) as any[];
  const events = (db.prepare('SELECT * FROM events WHERE conversation_id=? ORDER BY created_at,rowid')
    .all(incident.conversation_id) as any[]).map((event) => ({ ...event, data: JSON.parse(event.data) }));
  const intents = db.prepare('SELECT id,status,bank_reference,operation_id,error,created_at FROM intents WHERE user_id=? AND conversation_id=? ORDER BY created_at')
    .all(incident.user_id, incident.conversation_id);
  let bank: { accounts: unknown[]; operations: unknown[] } | null = null;
  let gaps = 'Historical conversations may have no recorded tools or events; absent telemetry is not evidence of no banking activity.';
  try {
    bank = await bankRequest(operatorId, `/v1/operator/customer?id=${encodeURIComponent(incident.user_id)}`);
  } catch {
    gaps += ' Live bank verification is temporarily unavailable.';
  }
  return {
    incident, customer: person(incident.user_id), lastMessage: history.at(-1) || null,
    history, events, intents, bank, gaps,
  };
}
