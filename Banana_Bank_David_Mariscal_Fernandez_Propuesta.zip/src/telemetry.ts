import { randomUUID } from 'node:crypto';
import { appDb } from './db';
import type { ToolContext } from './types';
export function recordEvent(ctx: ToolContext, kind: string, data: Record<string, unknown>) {
  // Keep auditable facts without storing full retrieved documents or raw banking snapshots.
  const input = data.input || data.arguments;
  const args = input && typeof input === 'object' ? input as Record<string, unknown> : null;
  const output = data.output && typeof data.output === 'object' ? data.output as Record<string, unknown> : null;
  const safe = {
    tool: data.tool, status: data.status, intentId: data.intentId,
    durationMs: data.durationMs, error: data.error,
    fromAccountId: args?.fromAccountId, toAccountId: args?.toAccountId,
    amountCents: args?.amountCents, concept: args?.concept,
    reference: data.reference || (data.operation as Record<string, unknown> | undefined)?.reference || output?.reference,
    operationId: (data.operation as Record<string, unknown> | undefined)?.id || output?.operationId,
    approvalId: output?.approvalId,
  };
  appDb().prepare('INSERT INTO events VALUES(?,?,?,?,?,?,?)').run(
    randomUUID(), ctx.runId, ctx.userId, ctx.conversationId,
    kind, JSON.stringify(safe), new Date().toISOString(),
  );
}
