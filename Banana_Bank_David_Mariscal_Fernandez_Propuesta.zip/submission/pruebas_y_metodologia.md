# Pruebas y metodología

Fecha: 11 de octubre de 2026.

## Resultados reproducidos

| Comprobación | Resultado observado | Entorno |
|---|---|---|
| Pruebas funcionales auxiliares | **21 ejecutadas, 21 superadas** | Node 22.16.0 + arnés de compatibilidad |
| Análisis sintáctico TS/TSX | **38 archivos examinados, 0 errores de sintaxis** | TypeScript `transpileModule` |
| Integridad de ZIP | Verificación CRC y listado íntegro | Python `zipfile` |

La salida original de la primera comprobación se conserva en `submission/pruebas_funcionales.tap`. Se ejecuta con:

```bash
node submission/validation-harness/run.mjs
```

La suite emplea el código TypeScript del proyecto, un servicio bancario HTTP local y una base SQLite real mediante `node:sqlite`. El arnés sustituye para esa ejecución parte del acceso a `better-sqlite3`, Zod y módulos de integración externa. Su propósito es comprobar flujos y regresiones bancarias de manera reproducible; **su resultado corresponde a ese entorno de compatibilidad**, no a una ejecución del build Next.js nativo.

### Escenarios incluidos

- Propuesta y confirmación de transferencias con referencia bancaria estable.
- Prevención de segunda ejecución por reintento y doble confirmación concurrente.
- Consulta del resultado tras respuesta perdida del banco.
- Rechazo del banco antes del commit, indisponibilidad de consulta y conciliación.
- Protección ante token erróneo, contexto de otro cliente, modificación del importe y aprobación caducada.
- Rechazo de peticiones POST de origen cruzado.
- Comprobación determinista de reglas informativas de Banana Check.
- Integridad de históricos de simulación, cuenta, sesión firmada y corpus documental.

### Comprobación de referencia en el entorno oficial

El proyecto incluye el script `npm run verify:node24` para automatizar instalación, tipos, pruebas y compilación usando las dependencias declaradas en `package-lock.json`. La versión objetivo es Node.js 24 o superior, como especifica el proyecto base.

La revisión de Banana Check utiliza información de saldos y movimientos simulados. Sus indicadores son informativos y no sustituyen la autorización explícita de la operación.
