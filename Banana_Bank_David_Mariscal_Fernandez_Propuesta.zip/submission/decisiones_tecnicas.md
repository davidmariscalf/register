# Decisiones técnicas

## Criterios de prioridad

La acción bancaria más crítica es una transferencia: un reintento que vuelva a emitir un movimiento distinto puede producir un doble cargo, mientras que una ejecución sin aprobación puede iniciar un movimiento no deseado. Se priorizó el flujo de pagos y la incertidumbre de red porque afecta directamente a la integridad del saldo simulado.

## Implementación de la parte 1

1. El agente prepara una propuesta de transferencia; la confirmación corresponde a la interfaz del cliente.
2. El servidor crea una referencia estable para cada intención y conserva los datos validados.
3. La confirmación comprueba contexto, titularidad, importe y vencimiento.
4. Una respuesta ambigua del servicio del banco origina una conciliación de solo lectura; la aplicación evita crear arbitrariamente nuevas referencias.
5. La vista del operador muestra hechos registrados y distingue los eventos observados de los datos históricos narrativos.

Archivos principales: `src/banking/actions.ts`, `dispatch.ts`, `authorization.ts`, `src/agent/tools.ts`, `app/api/[...path]/route.ts` y `app/page.tsx`.

## Implementación de la parte 2

**Banana Check** usa el saldo, la cuenta de origen, la cuenta destinataria, el importe y el historial de operaciones. Devuelve una evaluación explicable con señales por saldo residual bajo, repetición, importe elevado respecto al saldo y relación con el destinatario. Su herramienta se diseña como lectura pura: explorar el riesgo nunca ejecuta una transferencia.

Archivos principales: `src/banking/review.ts`, `src/agent/tools.ts`, `app/api/[...path]/route.ts` y `app/page.tsx`.

## Preservación del contrato

La aplicación sigue la API bancaria definida en `docs/contracts.md`. El simulador (`simulator/`) se conserva sin cambios de comportamiento. Los datos siguen siendo ficticios y no se debe equiparar el selector de perfiles de demostración con autenticación bancaria de producción.

## Evidencia

Las comprobaciones auxiliares y el enfoque de su reproducción se describen en `pruebas_y_metodologia.md`; la salida TAP se conserva sin editar en `pruebas_funcionales.tap`. La presentación `presentacion.pdf` documenta el recorrido funcional propuesto.
