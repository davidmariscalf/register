# Registro reconstruido de colaboración con IA — Banana Bank

**Candidato:** David Mariscal Fernández  
**Fecha del reto:** octubre de 2026  
**Procedencia:** síntesis documental de los mensajes visibles recuperados de la conversación de trabajo, las capturas de la convocatoria y los artefactos generados. Este registro es una **reconstrucción editorial**, no una transcripción literal ni un archivo exportado automáticamente por una plataforma.

## Secuencia documentada

**1. Identificación del reto.** El candidato pidió resolver el desafío de t·Dots de principio a fin y facilitó capturas del recordatorio. El asistente localizó el repositorio público `TDOTS-TEAM/challenge-banana-candidate` y explicó cómo descargar el proyecto original.

**2. Revisión del material.** Tras recibir el archivo ZIP, se revisaron el documento `docs/challenge.md`, las instrucciones de instalación, los contratos de la API bancaria y las rutas del agente, la interfaz y las pruebas existentes. El desafío exigía dos componentes: mejorar la fiabilidad de la aplicación y crear una funcionalidad distintiva del agente.

**3. Identificación de escenarios críticos.** Se priorizaron los reintentos de una transferencia después de perder una respuesta, el control de autorización y la confirmación expresa de las operaciones. Se optó por mantener el servicio de simulación como dependencia externa.

**4. Diseño del cambio.** El flujo se dividió en creación de propuesta, revisión, confirmación y conciliación. Para cada intención se mantiene una referencia bancaria estable. Banana Check se definió como revisión preventiva de solo lectura, basada en datos del banco.

**5. Implementación de la experiencia.** Se trabajó sobre las herramientas del agente, las acciones de banca, el endpoint de la aplicación y el panel de transferencias. Se añadieron avisos explicables y recuperación de operaciones ambiguas, junto con trazabilidad del operador.

**6. Comprobaciones.** Se añadieron pruebas para operación normal, respuesta perdida, rechazo antes de confirmar, consulta bancaria temporalmente indisponible y referencias repetidas. La revisión posterior añadió autorizaciones vencidas, contextos ajenos, cambios de importe, origen cruzado y confirmaciones simultáneas. En la última ejecución registrada, el conjunto auxiliar superó 21 de 21 pruebas bajo Node 22.16.0 con un arnés de compatibilidad. Se examinaron sintácticamente 38 archivos TS/TSX con cero errores.

**7. Preparación de la presentación.** Se creó una presentación en PDF para explicar el problema, la solución, las decisiones de diseño y las rutas para reproducir las pruebas.

## Decisiones tomadas durante la colaboración

- No aceptar que el asistente ejecute dinero sin aprobación del cliente.
- Conservar una referencia de operación para obtener idempotencia a través de reintentos.
- Consultar el libro bancario antes de decidir el estado de una operación incierta.
- Diferenciar hechos del simulador de indicios heurísticos o documentación histórica.
- Mantener el simulador externo sin cambios, respetando `docs/contracts.md`.
- Aportar pruebas reproducibles y un documento explicativo junto al código.

## Referencias cruzadas

- `../decisiones_tecnicas.md`: justificación técnica de los cambios.
- `../pruebas_y_metodologia.md` y `../pruebas_funcionales.tap`: ejecución y metodología.
- `../presentacion.pdf`: explicación de la entrega.
- `attachments/convocatoria_tDots_1.jpg` y `attachments/convocatoria_tDots_2.jpg`: capturas de la convocatoria aportadas por el candidato.

Las descripciones de esta bitácora son síntesis de actividades documentadas, no mensajes adicionales atribuidos ficticiamente al usuario o al asistente.
