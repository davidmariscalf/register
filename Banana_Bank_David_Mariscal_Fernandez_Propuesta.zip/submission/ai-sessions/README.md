# Registro de colaboración con IA

- `registro_de_colaboracion_ia.md`: bitácora reconstruida a partir de material recuperable. Su procedencia editorial está declarada en la cabecera.
- `attachments/`: capturas de la convocatoria aportadas por el candidato.

Los detalles técnicos verificables se incluyen en `../decisiones_tecnicas.md` y `../pruebas_y_metodologia.md`.
