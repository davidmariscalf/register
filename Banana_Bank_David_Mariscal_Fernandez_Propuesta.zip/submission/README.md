# Banana Bank — entrega técnica

**Candidato:** David Mariscal Fernández  
**Proyecto:** Banana Bank / reto t·Dots  
**Versión del dossier:** 11 de octubre de 2026

## Visión general

La solución se organiza alrededor de dos mejoras: hacer predecibles y seguras las transferencias simuladas y ofrecer al cliente una revisión preventiva de la operación mediante **Banana Check**. El servicio del banco en `simulator/` se trata como una dependencia externa y se consume mediante su API.

### Parte 1. Preparación para operar

- **Propuesta antes de ejecución.** El agente prepara los datos; la interfaz muestra origen, destino e importe antes de autorizar.
- **Referencia bancaria estable.** Los reintentos reutilizan la misma referencia e intentan conciliar el estado ya registrado.
- **Estados inciertos explícitos.** Tras una respuesta perdida, la aplicación consulta el estado de la operación antes de asumir el resultado.
- **Autorización y separación de contextos.** La confirmación se asocia al usuario, a la propuesta y a los detalles firmados. Se comprueban expiración y modificaciones.
- **Trazabilidad del operador.** La interfaz presenta contexto registrado de conversaciones, operaciones y atención al cliente.

### Parte 2. Banana Check

Una revisión de solo lectura integra saldos bancarios, historial relevante, receptor e importe. Presenta saldo tras la operación, señales de repetición y avisos cuando una operación consume una proporción importante del saldo. No ejecuta movimientos ni atribuye a esas reglas una certeza de detección de fraude.

## Cómo probar el proyecto

Requisito: Node.js 24+, npm y, para el chat generativo, una clave OpenAI válida para los modelos indicados por el proyecto.

```bash
npm ci
npm run setup
# configurar OPENAI_API_KEY en .env.local
npm run doctor
npm run dev
```

Abrir `http://127.0.0.1:3000`. La aplicación y el servicio bancario local se arrancan conjuntamente. Para un reset reproducible, detener los servicios y ejecutar `npm run reset`.

Verificaciones estándar disponibles:

```bash
npm run typecheck
npm test
npm run build
```

Para reproducir las pruebas funcionales auxiliares del paquete en un entorno Node 22 que cuente con TypeScript:

```bash
node submission/validation-harness/run.mjs
```

El dossier de pruebas identifica el entorno concreto y los componentes usados en esa ejecución. También incluye la salida TAP generada.

## Demostración sugerida

1. Seleccionar a Diego, abrir **Transfers** y realizar la vista previa de un envío de 30 € a Bruno con Banana Check.
2. Comprobar que la vista previa no ha modificado el saldo bancario.
3. Crear una propuesta y revisar sus datos antes de confirmarla.
4. Confirmar; consultar el movimiento y volver a solicitar su estado, observando que no se genera otro cargo.
5. Usar `npm run scenario -- lost-response`, repetir con otra propuesta y mostrar la consulta de recuperación.
6. Cambiar al contexto del operador Marta para explorar los casos y hechos bancarios registrados.

## Material incluido

| Archivo | Contenido |
|---|---|
| `presentacion.pdf` | Explicación visual de las dos partes y de las decisiones |
| `pruebas_y_metodologia.md` | Resultados verificables y entorno de prueba |
| `pruebas_funcionales.tap` | Salida sin editar de las pruebas auxiliares |
| `validation-harness/` | Código para reproducir la comprobación auxiliar |
| `decisiones_tecnicas.md` | Problemas, solución y criterios de diseño |
| `ai-sessions/registro_de_colaboracion_ia.md` | Registro reconstruido de conversaciones y decisiones a partir de material recuperable |
| `ai-sessions/attachments/` | Capturas de la convocatoria facilitadas en la conversación |
| `manifest_sha256.json` | Huellas de los ficheros entregados |

El código de la aplicación se encuentra en `app/`, `src/` y `tests/`, junto al servicio de simulación de referencia en `simulator/`. El contrato del ejercicio se conserva en `docs/`.
