export default class OpenAI {constructor(){throw new Error('Offline compatibility runner deliberately has no AI provider capability');}}
