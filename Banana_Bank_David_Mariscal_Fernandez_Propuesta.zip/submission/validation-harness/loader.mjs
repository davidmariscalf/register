import { createRequire } from 'node:module';
import { readFile } from 'node:fs/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import path from 'node:path';
const require = createRequire(import.meta.url);
let ts;
try { ts = require('typescript'); }
catch {
  try { ts = require(path.join(path.dirname(process.execPath), '..', 'lib', 'node_modules', 'typescript')); }
  catch { throw new Error('Compatibility harness requires a globally or locally installed TypeScript compiler.'); }
}
const stubDir = path.dirname(fileURLToPath(import.meta.url));
const alias = {'zod':'zod.mjs','dotenv':'dotenv.mjs','better-sqlite3':'sqlite.mjs','openai':'openai.mjs', 'openai/lib/responses/ResponseInputItems':'responses.mjs','tsx':'tsx.mjs'};
export async function resolve(specifier, context, nextResolve) {
  if(alias[specifier]) return {url:pathToFileURL(path.join(stubDir,alias[specifier])).href, shortCircuit:true};
  if(specifier.startsWith('.') && context.parentURL && context.parentURL.startsWith('file:')){
    const base = fileURLToPath(new URL(specifier,context.parentURL));
    if(!path.extname(base)){
      try {const {access} = await import('node:fs/promises');await access(base+'.ts');return {url:pathToFileURL(base+'.ts').href,shortCircuit:true};}catch{}
      try {const {access} = await import('node:fs/promises');await access(base+'.tsx');return {url:pathToFileURL(base+'.tsx').href,shortCircuit:true};}catch{}
    }
  }
  return nextResolve(specifier,context);
}
export async function load(url,context,nextLoad){
  if(url.endsWith('.ts')||url.endsWith('.tsx')){
    const source=await readFile(fileURLToPath(url),'utf8');
    const output=ts.transpileModule(source,{fileName:fileURLToPath(url),compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext,jsx:ts.JsxEmit.ReactJSX}}).outputText;
    return {format:'module',source:output,shortCircuit:true};
  }
  return nextLoad(url,context);
}
