export function toResponseInputItems(){throw new Error('Offline runner does not invoke LLMs');}
