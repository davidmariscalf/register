import { DatabaseSync } from 'node:sqlite';
export default class DatabaseCompat {
  constructor(path){this.db=new DatabaseSync(path);}
  pragma(expr){return this.db.exec('PRAGMA '+expr);}
  exec(sql){return this.db.exec(sql);}
  prepare(sql){return this.db.prepare(sql);}
  transaction(fn){return (...args)=>{
    this.db.exec('BEGIN');
    try {const r=fn(...args);this.db.exec('COMMIT');return r;} catch(e){this.db.exec('ROLLBACK'); throw e;}
  };}
  close(){this.db.close();}
}
