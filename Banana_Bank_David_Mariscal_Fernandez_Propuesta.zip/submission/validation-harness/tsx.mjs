// noop: offline test runs under a dedicated ESM TypeScript loader
