/** Optional Node 22 compatibility run. NOT a substitute for actual Node 24/npm tests. */
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const loader = path.join(root, 'submission/validation-harness/loader.mjs');
const options = `${process.env.NODE_OPTIONS ?? ''} --no-warnings --experimental-loader=${loader}`;
const cmd = spawnSync(process.execPath, ['--test', 'tests/banana-check.test.ts', 'tests/invariants.test.ts', 'tests/transfer-workflow.test.ts'],
  {cwd:root, env:{...process.env,NODE_OPTIONS:options},stdio:'inherit'});
if (cmd.error) console.error(cmd.error);
process.exit(cmd.status ?? 1);
