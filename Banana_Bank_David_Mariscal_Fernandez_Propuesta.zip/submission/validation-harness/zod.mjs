export class ZodError extends Error {}
class S {
  constructor(type,shape){this.type=type;this.shape=shape;this.mods=[];this.closed=false;}
  strict(){this.closed=true;return this;}
  min(n){this.mods.push(['min',n]);return this;}
  max(n){this.mods.push(['max',n]);return this;}
  int(){this.mods.push(['int']);return this;}
  positive(){this.mods.push(['positive']);return this;}
  trim(){this.mods.push(['trim']);return this;}
  optional(){this.mods.push(['optional']);return this;}
  nullable(){this.mods.push(['nullable']);return this;}
  _bad(msg){throw new ZodError(msg);}
  parse(input){
    if(input===undefined && this.mods.some(([m])=>m==='optional'))return undefined;
    if(input===null && this.mods.some(([m])=>m==='nullable'))return null;
    if(this.type==='unknown')return input;
    if(this.type==='string'){
      if(typeof input!=='string')this._bad('string expected');
      let v=input;
      for(const [m,n] of this.mods){if(m==='trim')v=v.trim();if(m==='min'&&v.length<n)this._bad('too short');if(m==='max'&&v.length>n)this._bad('too long');}
      return v;
    }
    if(this.type==='number'){
      if(typeof input!=='number'||!Number.isFinite(input))this._bad('number expected');
      for(const [m,n] of this.mods){if(m==='int'&&!Number.isInteger(input))this._bad('not integer');if(m==='positive'&&input<=0)this._bad('not positive');if(m==='max'&&input>n)this._bad('too large')}
      return input;
    }
    if(this.type==='enum'){if(!this.shape.includes(input))this._bad('invalid enum');return input;}
    if(this.type==='array'){
      if(!Array.isArray(input))this._bad('array expected');
      for(const [m,n] of this.mods){if(m==='max'&&input.length>n)this._bad('too many items');}
      return input.map(x=>this.shape.parse(x));
    }
    if(this.type==='object'){
      if(!input||typeof input!=='object'||Array.isArray(input))this._bad('object expected');
      if(this.closed && Object.keys(input).some(k=>!(k in this.shape)))this._bad('unknown field');
      return Object.fromEntries(Object.entries(this.shape).filter(([k])=>k in input || !this.shape[k].mods.some(([m])=>m==='optional')).map(([k,s])=>[k,s.parse(input[k])]).filter(([k,v])=>v!==undefined));
    }
    this._bad('unsupported schema '+this.type);
  }
}
export const z={object:(s)=>new S('object',s), string:()=>new S('string'), number:()=>new S('number'),unknown:()=>new S('unknown'),enum:(values)=>new S('enum',values),array:(s)=>new S('array',s),ZodError};
